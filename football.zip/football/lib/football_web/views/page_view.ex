defmodule FootballWeb.PageView do
  use FootballWeb, :view
end
