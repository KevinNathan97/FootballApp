defmodule FootballWeb.LayoutView do
  use FootballWeb, :view
end
