defmodule FootballWeb.LayoutViewTest do
  use FootballWeb.ConnCase, async: true
end
