defmodule FootballWeb.PageViewTest do
  use FootballWeb.ConnCase, async: true
end
