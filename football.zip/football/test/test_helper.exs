ExUnit.start()
Ecto.Adapters.SQL.Sandbox.mode(Football.Repo, :manual)
