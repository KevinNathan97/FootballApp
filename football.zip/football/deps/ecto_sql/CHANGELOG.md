# Changelog for v3.0

## v3.0.0-rc.1 (2018-10-29)

  * Initial release. Note support for `mariaex` will be deprecated in a future patch release in favor of the upcoming `myxql` driver, which is being finalized.
